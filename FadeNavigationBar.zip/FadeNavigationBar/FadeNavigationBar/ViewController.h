//
//  ViewController.h
//  FadeNavigationBar
//
//  Created by timtian on 16/9/20.
//  Copyright © 2016年 timtian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property(nonatomic,strong)UITableView * tableView;

@end

